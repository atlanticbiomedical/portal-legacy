<?php

/**
 * Subclass for performing query and update operations on the 'workorder_type' table.
 *
 * 
 *
 * @package lib.model
 */ 
class WorkorderTypePeer extends BaseWorkorderTypePeer
{
}
