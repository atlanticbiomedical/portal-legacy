<?php

/**
 * Subclass for performing query and update operations on the 'qualifications' table.
 *
 * 
 *
 * @package lib.model
 */ 
class QualificationsPeer extends BaseQualificationsPeer
{
}
