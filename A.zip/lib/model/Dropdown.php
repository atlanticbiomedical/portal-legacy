<?php

/**
 * Subclass for representing a row from the 'dropdown' table.
 *
 * 
 *
 * @package lib.model
 */ 
class Dropdown extends BaseDropdown
{
}
