<?php

/**
 * Subclass for representing a row from the 'workorder_type' table.
 *
 * 
 *
 * @package lib.model
 */ 
class WorkorderType extends BaseWorkorderType
{
}
