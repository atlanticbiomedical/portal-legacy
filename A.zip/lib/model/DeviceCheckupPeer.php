<?php

/**
 * Subclass for performing query and update operations on the 'device_checkup' table.
 *
 * 
 *
 * @package lib.model
 */ 
class DeviceCheckupPeer extends BaseDeviceCheckupPeer
{
}
