<?php

/**
 * Subclass for representing a row from the 'qualifications' table.
 *
 * 
 *
 * @package lib.model
 */ 
class Qualifications extends BaseQualifications
{
}
