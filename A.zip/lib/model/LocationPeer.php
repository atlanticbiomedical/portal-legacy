<?php

/**
 * Subclass for performing query and update operations on the 'location' table.
 *
 * 
 *
 * @package lib.model
 */ 
class LocationPeer extends BaseLocationPeer
{
}
