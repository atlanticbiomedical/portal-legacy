<?php

/**
 * Subclass for performing query and update operations on the 'dropdown' table.
 *
 * 
 *
 * @package lib.model
 */ 
class DropdownPeer extends BaseDropdownPeer
{
}
