<?php

/**
 * Subclass for performing query and update operations on the 'cordinates' table.
 *
 * 
 *
 * @package lib.model
 */ 
class CordinatesPeer extends BaseCordinatesPeer
{
}
