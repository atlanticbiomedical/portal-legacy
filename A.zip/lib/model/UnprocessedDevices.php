<?php

/**
 * Subclass for representing a row from the 'unprocessed_devices' table.
 *
 * 
 *
 * @package lib.model
 */ 
class UnprocessedDevices extends BaseUnprocessedDevices
{
}
