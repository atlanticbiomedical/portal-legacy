<?php

/**
 * Subclass for performing query and update operations on the 'device_test_data' table.
 *
 * 
 *
 * @package lib.model
 */ 
class DeviceTestDataPeer extends BaseDeviceTestDataPeer
{
}
