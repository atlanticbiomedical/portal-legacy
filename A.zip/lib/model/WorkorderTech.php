<?php

/**
 * Subclass for representing a row from the 'workorder_tech' table.
 *
 * 
 *
 * @package lib.model
 */ 
class WorkorderTech extends BaseWorkorderTech
{



}
