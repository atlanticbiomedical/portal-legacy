<?php

/**
 * Subclass for representing a row from the 'distances' table.
 *
 * 
 *
 * @package lib.model
 */ 
class Distances extends BaseDistances
{
}
