<?php

/**
 * Subclass for performing query and update operations on the 'final_device_report' table.
 *
 * 
 *
 * @package lib.model
 */ 
class FinalDeviceReportPeer extends BaseFinalDeviceReportPeer
{
}
