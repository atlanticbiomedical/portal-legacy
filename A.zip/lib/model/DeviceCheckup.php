<?php

/**
 * Subclass for representing a row from the 'device_checkup' table.
 *
 * 
 *
 * @package lib.model
 */ 
class DeviceCheckup extends BaseDeviceCheckup
{
}
