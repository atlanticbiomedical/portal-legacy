<?php

/**
 * Subclass for representing a row from the 'device_test_data' table.
 *
 * 
 *
 * @package lib.model
 */ 
class DeviceTestData extends BaseDeviceTestData
{
}
