<?php

/**
 * Subclass for representing a row from the 'tech_distances' table.
 *
 * 
 *
 * @package lib.model
 */ 
class TechDistances extends BaseTechDistances
{
}
