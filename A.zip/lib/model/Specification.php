<?php

/**
 * Subclass for representing a row from the 'specification' table.
 *
 * 
 *
 * @package lib.model
 */ 
class Specification extends BaseSpecification
{
}
