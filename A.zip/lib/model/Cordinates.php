<?php

/**
 * Subclass for representing a row from the 'cordinates' table.
 *
 * 
 *
 * @package lib.model
 */ 
class Cordinates extends BaseCordinates
{
}
