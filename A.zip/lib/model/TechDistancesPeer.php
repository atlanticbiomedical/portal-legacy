<?php

/**
 * Subclass for performing query and update operations on the 'tech_distances' table.
 *
 * 
 *
 * @package lib.model
 */ 
class TechDistancesPeer extends BaseTechDistancesPeer
{
}
