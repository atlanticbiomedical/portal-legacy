<?php

/**
 * Subclass for representing a row from the 'user_type' table.
 *
 * 
 *
 * @package lib.model
 */ 
class UserType extends BaseUserType
{
}
