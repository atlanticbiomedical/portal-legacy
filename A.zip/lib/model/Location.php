<?php

/**
 * Subclass for representing a row from the 'location' table.
 *
 * 
 *
 * @package lib.model
 */ 
class Location extends BaseLocation
{
}
