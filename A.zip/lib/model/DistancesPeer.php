<?php

/**
 * Subclass for performing query and update operations on the 'distances' table.
 *
 * 
 *
 * @package lib.model
 */ 
class DistancesPeer extends BaseDistancesPeer
{
}
