<?php

/**
 * Subclass for performing query and update operations on the 'unprocessed_devices' table.
 *
 * 
 *
 * @package lib.model
 */ 
class UnprocessedDevicesPeer extends BaseUnprocessedDevicesPeer
{
}
