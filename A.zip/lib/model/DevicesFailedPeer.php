<?php

/**
 * Subclass for performing query and update operations on the 'devices_failed' table.
 *
 * 
 *
 * @package lib.model
 */ 
class DevicesFailedPeer extends BaseDevicesFailedPeer
{
}
