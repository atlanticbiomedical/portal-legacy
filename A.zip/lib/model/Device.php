<?php

/**
 * Subclass for representing a row from the 'device' table.
 *
 * 
 *
 * @package lib.model
 */ 
class Device extends BaseDevice
{
}
