<?php

/**
 * Subclass for performing query and update operations on the 'devices_files' table.
 *
 * 
 *
 * @package lib.model
 */ 
class DevicesFilesPeer extends BaseDevicesFilesPeer
{
}
