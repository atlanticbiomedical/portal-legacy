<?php

/**
 * Subclass for representing a row from the 'devices_failed' table.
 *
 * 
 *
 * @package lib.model
 */ 
class DevicesFailed extends BaseDevicesFailed
{
}
