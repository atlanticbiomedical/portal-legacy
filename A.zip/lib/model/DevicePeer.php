<?php

/**
 * Subclass for performing query and update operations on the 'device' table.
 *
 * 
 *
 * @package lib.model
 */ 
class DevicePeer extends BaseDevicePeer
{
}
