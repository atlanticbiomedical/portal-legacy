<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<head>

<?php include_http_metas() ?>
<?php include_metas() ?>

</head>
<body>

<!-- <div class="content"> -->
<?php echo $sf_data->getRaw('sf_content') ?>
<!-- </div> -->
</body>
</html>
