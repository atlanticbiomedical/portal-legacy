<?php
include_partial('device',array('devices'=>$devices)); ?>