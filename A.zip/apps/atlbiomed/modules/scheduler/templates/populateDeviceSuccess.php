<?php use_helper('Javascript'); ?>
<?php echo select_tag('device_select', options_for_select($device_options)); ?>
