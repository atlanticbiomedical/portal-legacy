<?php include_component('maps', 'displayTechnicianMap', array('markers' => $markers, 'mapwidth' => '500px', 'mapheight' => '400px')); ?>
	
