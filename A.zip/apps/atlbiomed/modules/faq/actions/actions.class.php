<?php

/**
 * faq actions.
 *
 * @package    atlbiomed
 * @subpackage faq
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 2692 2006-11-15 21:03:55Z fabien $
 */
class faqActions extends sfActions
{
  /**
   * Executes index action
   *
   */
  public function executeIndex()
  {
  }
}
