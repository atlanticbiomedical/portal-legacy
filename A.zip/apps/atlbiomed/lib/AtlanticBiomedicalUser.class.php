<?php

class AtlanticBiomedicalUser extends sfBasicSecurityUser
{
}
