<?php

// symfony directories
$sf_symfony_lib_dir  = '##SYMFONY_LIB_DIR##';
$sf_symfony_data_dir = '##SYMFONY_DATA_DIR##';
