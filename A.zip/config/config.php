<?php

// symfony directories
$sf_symfony_lib_dir  = realpath(dirname(__FILE__).'/../lib/symfony'); 
$sf_symfony_data_dir = realpath(dirname(__FILE__).'/../data/symfony');