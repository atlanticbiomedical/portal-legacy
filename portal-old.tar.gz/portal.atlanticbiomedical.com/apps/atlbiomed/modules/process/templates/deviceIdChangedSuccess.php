<?php
include_partial('device_changed',array('oldDevice'=>$oldDevice, 'newDevice'=>$newDevice))
?>