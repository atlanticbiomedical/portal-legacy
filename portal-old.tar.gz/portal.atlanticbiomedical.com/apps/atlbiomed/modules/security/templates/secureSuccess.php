<div class="secureModuleMain">
	<div class="secureModuleMessage">
		<?php echo image_tag('lock48'); ?>
		<div>You are not authorized to view this page.  Click <?php echo link_to('here', 'security/logout'); ?> to return to the application.</div>
	</div>
</div>