ALTER TABLE `client`
  ADD `frequency_annual` MEDIUMBLOB,
  ADD `frequency_semi` MEDIUMBLOB,
  ADD `frequency_quarterly` MEDIUMBLOB,
  ADD `frequency_sterilizer` MEDIUMBLOB,
  ADD `frequency_tg` MEDIUMBLOB,
  ADD `frequency_ert` MEDIUMBLOB,
  ADD `frequency_rae` MEDIUMBLOB,
  ADD `frequency_medgas` MEDIUMBLOB,
  ADD `frequency_imaging` MEDIUMBLOB,
  ADD `frequency_neptune` MEDIUMBLOB,
  ADD `frequency_anesthesia` MEDIUMBLOB;

