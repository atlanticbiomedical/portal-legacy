<?php

/**
 * Subclass for performing query and update operations on the 'user_type' table.
 *
 * 
 *
 * @package lib.model
 */ 
class UserTypePeer extends BaseUserTypePeer
{
}
