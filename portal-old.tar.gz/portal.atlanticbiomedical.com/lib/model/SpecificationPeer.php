<?php

/**
 * Subclass for performing query and update operations on the 'specification' table.
 *
 * 
 *
 * @package lib.model
 */ 
class SpecificationPeer extends BaseSpecificationPeer
{
}
